package com.santossingh.projectmovieapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import java.util.List;


public class CustomAdapter extends ArrayAdapter {
    private List<MovieModel> movieList;
    private int resource;
    private LayoutInflater inflater;

    public CustomAdapter(Context context, int resource, List<MovieModel> objects) {
        super(context, resource, objects);
        movieList=objects;
        this.resource=resource;
        inflater=(LayoutInflater)getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView==null) {
            convertView = inflater.inflate(R.layout.list_image_forecast, parent,false);
        }
        String poster_path= movieList.get(position).getPoster_path();
        ImageView imageView = (ImageView)convertView.findViewById(R.id.imageView);
        // set image in imageView by Picasso API
        Picasso.with(convertView.getContext())
                .load("http://image.tmdb.org/t/p/w185/"+poster_path)
                .resize(240, 330)
                .into(imageView);

        return convertView;
    }
}
