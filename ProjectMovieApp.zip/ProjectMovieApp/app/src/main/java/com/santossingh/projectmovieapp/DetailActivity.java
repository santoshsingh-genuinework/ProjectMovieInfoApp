package com.santossingh.projectmovieapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

public class DetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        //Getting Extra_text via Intent and set it in movieTitle TextView-------------------
        Intent intent= getIntent();
        String movie_name=intent.getStringExtra("movie_Name");
        String movie_poster=intent.getStringExtra("poster_Path");
        String release_date=intent.getStringExtra("release_Date");
        Float users_rating=intent.getFloatExtra("users_Rating", 0);
        String overview=intent.getStringExtra("overview");

        TextView movie_Title=(TextView)findViewById(R.id.movieTitle);
        ImageView movie_Poster=(ImageView)findViewById(R.id.moviePoster);
        TextView movie_ReleaseDate=(TextView)findViewById(R.id.releaseDate);
        TextView movie_UserRating=(TextView)findViewById(R.id.rating_Percent);
        RatingBar movie_RatingStars=(RatingBar)findViewById(R.id.ratingBar);
        TextView movie_Overview=(TextView)findViewById(R.id.overViewDetail);

        Picasso.with(DetailActivity.this)
                .load("http://image.tmdb.org/t/p/w185/" + movie_poster)
                .resize(250, 320)
                .into(movie_Poster);

        movie_Title.setText(movie_name);
        movie_ReleaseDate.setText(release_date);
        movie_UserRating.setText(users_rating+"/10");
        movie_RatingStars.setRating(users_rating*5/10);
        movie_Overview.setText(overview);
    }

}

