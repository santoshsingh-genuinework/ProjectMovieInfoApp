package com.santossingh.projectmovieapp;

import android.app.Fragment;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.GridView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by Stark on 07-03-2016.
 */
public class ForecastFragment extends Fragment {
    private String API_KEY = "f074b4f71849509c940cd25d16e9cab9";
    private CustomAdapter movieAdapter = null;
    private GridView gridView;
    private View rootView=null;
    private List<MovieModel> movieModelList=null;
    //Constructor
    public ForecastFragment() {
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        //URL Addresses for High rating and Most popularity movies-----------
        String Top_rated = "http://api.themoviedb.org/3/discover/movie?" +
                "certification_country=US&certification=" +
                "R&sort_by=vote_average.desc&api_key=" + API_KEY;

        String Popularity = "http://api.themoviedb.org/3/discover/movie?" +
                "sort_by=popularity.desc&api_key=" + API_KEY;

        switch (item.getItemId()){
            case R.id.most_Popular:
                if(item.isChecked()){
                    item.setChecked(false);
                }else{
                    item.setChecked(true);
                    new ForecastTask().execute(Popularity);
                    return true;
                }
            case R.id.High_rated:
                if(item.isChecked()){
                    item.setChecked(false);
                }else{
                    item.setChecked(true);
                    new ForecastTask().execute(Top_rated);
                    return true;
                }
        }
        return super.onOptionsItemSelected(item);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.activity_main, container, false);

        String Popular_query = "http://api.themoviedb.org/3/discover/movie?sort_by=popularity" +
                ".desc&api_key=" + API_KEY;

        new ForecastTask().execute(Popular_query);

        return rootView;
    }

    //Creat ForecastTask extends with AsyncTask for getting info from URL.
    public class ForecastTask extends AsyncTask<String, String, List<MovieModel>> {

        private final String LOG_TAG = ForecastTask.class.getSimpleName();
        @Override
        protected List<MovieModel> doInBackground(String... params) {
            if (params.length == 0) {
                return null;
            }
            HttpURLConnection connection = null;
            BufferedReader reader = null;

            try {
                URL url = new URL(params[0]);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();

                InputStream inputStream = connection.getInputStream();
                if (inputStream == null) {
                    return null;
                }

                reader = new BufferedReader(new InputStreamReader(inputStream));
                StringBuffer buffer = new StringBuffer();
                String line;
                while ((line = reader.readLine()) != null) {
                    buffer.append(line);
                }

                JSONObject jsonObject = new JSONObject(buffer.toString());
                JSONArray jsonArray = jsonObject.getJSONArray("results");

                //adding JSON Array data into MovieModel Class
                movieModelList = new ArrayList<>();
                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject finalObject = jsonArray.getJSONObject(i);

                    MovieModel movieModel = new MovieModel();
                        movieModel.setId(finalObject.getInt("id"));
                        movieModel.setPoster_path(finalObject.getString("poster_path"));
                        movieModel.setTitle(finalObject.getString("title"));
                        movieModel.setRelease_date(finalObject.getString("release_date"));
                        movieModel.setVote_average((float) finalObject.getDouble("vote_average"));
                        movieModel.setOverview(finalObject.getString("overview"));
                        movieModel.setBackdrop_path(finalObject.getString("backdrop_path"));
                    movieModelList.add(movieModel);
                }

                return movieModelList;
            } catch (JSONException | IOException e) {
                e.printStackTrace();
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
                try {
                    if (reader != null) {
                        reader.close();
                    }
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
            return null;
        }

        @Override
        protected void onPostExecute(final List<MovieModel> movieModels) {
            super.onPostExecute(movieModels);
            //movieAdapter initialization and set in gridView
            movieAdapter = new CustomAdapter(
                    getActivity(),
                    R.layout.list_image_forecast,
                    movieModels);

            gridView = (GridView) rootView.findViewById(R.id.gridView);
            gridView.setAdapter(movieAdapter);

            //Set on Item click listener on gridview
            gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                    //String item_url = parent.getItemAtPosition(position).toString();
                    //String.valueOf(parent..getSelectedItem(position));

                    String movie_name=movieModelList.get(position).getTitle();
                    String poster_path=movieModelList.get(position).getPoster_path();
                    String release_date=movieModelList.get(position).getRelease_date();
                    Float users_rating=movieModelList.get(position).getVote_average();
                    String overview=movieModelList.get(position).getOverview();

                    Intent intent = new Intent(getActivity(), DetailActivity.class)
                            .putExtra("movie_Name", movie_name)
                            .putExtra("poster_Path", poster_path)
                            .putExtra("release_Date", release_date)
                            .putExtra("users_Rating", users_rating)
                            .putExtra("overview", overview);
                    startActivity(intent);
                }
            });
        }
    }
}
